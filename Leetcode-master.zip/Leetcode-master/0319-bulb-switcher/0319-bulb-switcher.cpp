class Solution {
public:
    int bulbSwitch(int n) {
 
        return sqrt(n);       
        
    }
};